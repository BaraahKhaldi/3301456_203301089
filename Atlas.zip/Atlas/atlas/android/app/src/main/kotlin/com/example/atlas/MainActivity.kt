package com.example.atlas

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
